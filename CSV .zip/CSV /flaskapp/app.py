from flask import Flask, render_template, request
import joblib
import pandas as pd
import os
from sklearn.preprocessing import  MinMaxScaler
import numpy as np

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/services')
def services():
    return render_template('services.html')

# Load the model at the start of the application
model_path = r'/Users/gwilliam/CSV /model.joblib'
rf_model = None

# scaler_path = 'scale.joblib'
# scaler = None
print("Loading model...")
if os.path.exists(model_path):
    rf_model = joblib.load(model_path)
    if rf_model is not None:
        print(f"Model loaded successfully from {model_path}.")
    else:
        print(f"Failed to load model from {model_path}.")
else:
    print(f"Model not found at {model_path}.")


def predict_Center_type(values):
    
    
    
    col = ['week', 'center_id', 'meal_id', 'checkout_price', 'base_price',
       'num_orders', 'category', 'cuisine', 'city_code', 'region_code',
       'op_area']
    

    # Create the DataFrame
    df = pd.DataFrame([values], columns=col)
    print('creating dataframe')
    print(df)

    # Initialize the StandardScaler
    # scaler = MinMaxScaler()
    # print('standard scaling is used')

    # Fit and transform the data using the scaler
    # X_scaled = scaler.fit_transform(df)
    # print('scaling is done')

    # Ensure the model is loaded
    if rf_model is None:
        raise ValueError("The model is not loaded. Check the model path and loading logic.")

    # Make a prediction
    prediction = rf_model.predict(df)
    print('Model predicting the class')
    print(prediction)

    # Map prediction to category labels (assuming 0: type_A, 1: type_C, 2: type_B)
    category_mapping = {0: 'TYPE_A', 1: 'TYPE_C', 2: 'TYPE_B'}
    predicted_category = category_mapping.get(prediction[0], 'unknown')

    return predicted_category

@app.route('/result', methods=['POST'])
def result():
    if request.method == 'POST':
        try:
            # Extract input values from the form or use predefined tuple
            values = None
            
            if 'input_values' in request.form and request.form['input_values']:
                values = list(map(float, request.form['input_values'].split(',')))
                print(values)

            # Ensure the correct number of values
            if len(values) == 11:
                predicted_category = predict_Center_type(values)
            else:
                raise ValueError("Invalid number of values. Expected 11 values.")

            # Redirect to the result page with the prediction
            return render_template('result.html', prediction=predicted_category)

        except Exception as e:
            print(f"Error occurred: {e}")
            return render_template('result.html', prediction=str(e))

if __name__ == '__main__':
    app.run(debug=True)